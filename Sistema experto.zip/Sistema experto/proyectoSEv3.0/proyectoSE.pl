:-use_module(library(pce)).
:-use_module(library(pce_style_item)).
:-pce_image_directory('./imagenes').
:-new(VentanaPrincipal,dialog('Sistema Experto Equipo 1')),
     new(Etiqueta,label(titulo,'SISTEMA EXPERTO PARA')),
     new(Etiqueta2,label(titulo2,'INICIAR UNA CONVERSACION')),
     new(BTNsalir, button('SALIR',message(VentanaPrincipal,destroy))),
     new(BTNusuario, button('COMENZAR',message(@prolog,irUsuario,VentanaPrincipal))),
     new(BTNexperto, button('AGREGAR CONOCIMIENTO',message(@prolog,irUsexperto,VentanaPrincipal))),

     send(Etiqueta,font,font(arial,bold,20)),
     send(Etiqueta2,font,font(arial,bold,20)),
     send(VentanaPrincipal,display,Etiqueta,point(40,0)),
     send(VentanaPrincipal,display,Etiqueta2,point(20,40)),
     send(VentanaPrincipal,display,BTNusuario,point(140,80)),
     send(VentanaPrincipal,display,BTNexperto,point(90,130)),
     send(VentanaPrincipal,display,BTNsalir,point(140,180)),
     send(VentanaPrincipal,open(point(100,100))).

irUsuario(Ventana):-
    send(Ventana,destroy),
    usuario.

irUsexperto(Ventana):-
    send(Ventana,destroy),
    usexperto.

regresarMenu(Ventana):-
     send(Ventana,destroy),
     new(VentanaPrincipal,dialog('Sistema Experto Equipo 1',size(100,200),display(top))),
     new(Etiqueta,label(titulo,'SISTEMA EXPERTO PARA')),
     new(Etiqueta2,label(titulo2,'INICIAR UNA CONVERSACION')),
     new(BTNsalir, button('SALIR',message(VentanaPrincipal,destroy))),
     new(BTNusuario, button('COMENZAR',message(@prolog,irUsuario,VentanaPrincipal))),
     new(BTNexperto, button('AGREGAR CONOCIMIENTO',message(@prolog,irUsexperto,VentanaPrincipal))),

     send(Etiqueta,font,font(arial,bold,20)),
     send(Etiqueta2,font,font(arial,bold,20)),
     send(VentanaPrincipal,display,Etiqueta,point(40,0)),
     send(VentanaPrincipal,display,Etiqueta2,point(20,40)),
     send(VentanaPrincipal,display,BTNusuario,point(140,80)),
     send(VentanaPrincipal,display,BTNexperto,point(90,130)),
     send(VentanaPrincipal,display,BTNsalir,point(140,180)),
     send(VentanaPrincipal,open(point(100,100))).

usexperto:-
    new(VentanaExperto,dialog('Interf�z Usuario Experto')),
    new(Etiqueta,label(titulo,'SISTEMA EXPERTO PARA INICIAR UNA CONVERSACION. USUARIO EXPERTO')),
    new(EtiqImg,label(info,'Escriba el nombre de la imagen seguido de la extension del archivo(.jpg, .jpeg o .bmp). Ejemplo: prueba.jpg')),
    new(EtiqImg2,label(info,'Deposite la imagen correspondiente en el directorio ./imagenes asegurandose que el tama�o de la misma sea 200px por 200px')),
    new(EtiqImg3,label(info,'Revise la informaci�n ingresada y verifique que todo sea correcto antes de dar clic en GUARDAR')),
    new(BTNsalir,button('REGRESAR AL MEN�',message(@prolog,regresarMenu,VentanaExperto))),
    new(Genero,
        menu('1-�Cu�l es el g�nero de la persona con la que quieres iniciar una conversaci�n?')),
    send_list(Genero, append,['Hombre','Mujer','No lo se']),
    new(Edad,
        menu('2-�Cu�l es la diferencia de edad de la persona con respecto a la tuya?')),
    send_list(Edad, append,['Es menor','Mismo rango de edad','Es mayor']),
    new(Familiaridad,
        menu('3-�Cu�l es la frecuencia con la que hablas con esa persona?')),
    send_list(Familiaridad, append,['Nunca hemos hablado','Hemos cruzado palabras','Hablamos frecuentemente']),
    new(Motivo,
        menu('4-�Cu�l es el motivo por el que quieres iniciar la conversaci�n?')),
    send_list(Motivo, append,['Platica Informal','Ligar','Platica Formal','Pedir informaci�n']),
    new(Respuesta,text_item('Escriba la respuesta experta')),
    new(Explicacion,text_item('Escriba la explicaci�n')),
    new(Img,text_item('Introduzca una im�gen')),
    new(BTNGuardar,button('GUARDAR',message(@prolog,guardarDatos,
                                           Genero?selection,
                                           Edad?selection,
                                           Familiaridad?selection,
                                           Motivo?selection,
                                           Respuesta?selection,
                                           Explicacion?selection,
                                           Img?selection,
                                           VentanaExperto))),



    send(Etiqueta,font,font(arial,bold,20)),
    send(Respuesta,size,size(1000)),
    send(Explicacion,size,size(1000)),
    send(Img,size,size(500)),
    send(VentanaExperto,display,Etiqueta,point(80,0)),
    send(VentanaExperto,display,Genero,point(10,40)),
    send(VentanaExperto,display,Edad,point(10,70)),
    send(VentanaExperto,display,Familiaridad,point(10,100)),
    send(VentanaExperto,display,Motivo,point(10,130)),
    send(VentanaExperto,display,Respuesta,point(10,160)),
    send(VentanaExperto,display,Explicacion,point(10,190)),
    send(VentanaExperto,display,Img,point(10,220)),
    send(VentanaExperto,display,EtiqImg,point(10,250)),
    send(VentanaExperto,display,EtiqImg2,point(10,270)),
    send(VentanaExperto,display,EtiqImg3,point(10,290)),
    send(VentanaExperto,display,BTNGuardar,point(400,320)),
    send(VentanaExperto,display,BTNsalir,point(600,320)),
    send(VentanaExperto,open(point(100,100))).

guardarDatos(Genero,Edad,Familiaridad,Motivo,Respuesta,Explicacion,Imagen,Ventana):-
    asserta(genero(Respuesta,Genero)),
    asserta(edad(Respuesta,Edad)),
    asserta(familiaridad(Respuesta,Familiaridad)),
    asserta(motivo(Respuesta,Motivo)),
    asserta(explicacion(Respuesta,Explicacion)),
    asserta(imagen(Respuesta,Imagen)),
    asserta(resource(Imagen,image,image(Imagen))),
    send(Ventana,destroy),
    usexperto.

usuario:-
    new(VentanaUsuario,dialog('Interfaz de Usuario')),
    new(Etiqueta,label(titulo,'SISTEMA EXPERTO PARA INICIAR UNA CONVERSACION')),
    new(BTNsalir,button('REGRESAR AL MEN�',message(@prolog,regresarMenu,VentanaUsuario))),
    new(Genero,
        menu('1-�Cu�l es el g�nero de la persona con la que quieres iniciar una conversaci�n?')),
    send_list(Genero, append,['Hombre','Mujer','No lo se']),
    new(Edad,
        menu('2-�Cu�l es la diferencia de edad de la persona con respecto a la tuya?')),
    send_list(Edad, append,['Es menor','Mismo rango de edad','Es mayor']),
    new(Familiaridad,
        menu('3-�Cu�l es la frecuencia con la que hablas con esa persona?')),
    send_list(Familiaridad, append,['Nunca hemos hablado','Hemos cruzado palabras','Hablamos frecuentemente']),
    new(Motivo,
        menu('4-�Cu�l es el motivo por el que quieres iniciar la conversaci�n?')),
    send_list(Motivo, append,['Platica Informal','Ligar','Platica Formal','Pedir informaci�n']),
    new(ResExperta,button('CONSULTAR',message(@prolog,consulta,
                                             Genero?selection,
                                             Edad?selection,
                                             Familiaridad?selection,
                                             Motivo?selection,
                                             VentanaUsuario))),

    send(Etiqueta,font,font(arial,bold,20)),
    send(VentanaUsuario,display,Etiqueta,point(140,0)),
    send(VentanaUsuario,display,Genero,point(10,40)),
    send(VentanaUsuario,display,Edad,point(10,70)),
    send(VentanaUsuario,display,Familiaridad,point(10,100)),
    send(VentanaUsuario,display,Motivo,point(10,130)),
    send(VentanaUsuario,display,ResExperta,point(250,160)),
    send(VentanaUsuario,display,BTNsalir,point(600,160)),
    send(VentanaUsuario,open(point(100,100))).

consulta(GeneroB,EdadB,FamiliaridadB,MotivoB,Ventana):-
    respuesta_experta(GeneroB,EdadB,FamiliaridadB,MotivoB,RespuestaB,ExplicacionB,ImagenB),

    new(VentanaUsuario,dialog('Interfaz de Usuario')),
    new(Etiqueta,label(titulo,'SISTEMA EXPERTO PARA INICIAR UNA CONVERSACION')),
    new(BTNsalir,button('REGRESAR AL MEN�',message(@prolog,regresarMenu,VentanaUsuario))),
    new(Genero,text_item('1-�Cu�l es el g�nero de la persona con la que quieres iniciar una conversaci�n?')),
    new(Edad,text_item('2-�Cu�l es la diferencia de edad de la persona con respecto a la tuya?')),
    new(Familiaridad,text_item('3-�Cu�l es la frecuencia con la que hablas con esa persona?')),
    new(Motivo,text_item('4-�Cu�l es el motivo por el que quieres iniciar la conversaci�n?')),
    new(CampoRes,text_item('Respuesta')),
    new(CampoImg,text_item('Imagen')),
    new(CampoExp,text_item('Explicaci�n')),
    new(ResExperta,button('VOLVER A CONSULTAR',message(@prolog,volverUsuario,VentanaUsuario))),

    new(ResExplicacion,button('PEDIR EXPLICACI�N',message(@prolog,mostarExplicacion,
                                                         VentanaUsuario,
                                                         CampoExp))),

    send(Etiqueta,font,font(arial,bold,20)),
    send(CampoRes,size,size(1000)),
    send(Genero,editable,false),
    send(Edad,editable,false),
    send(Familiaridad,editable,false),
    send(Motivo,editable,false),
    send(CampoRes,editable,false),
    send(CampoImg,editable,false),
    send(CampoExp,size,size(1000)),
    send(CampoExp,editable,false),
    send(Genero,selection,GeneroB),
    send(Edad,selection,EdadB),
    send(Familiaridad,selection,FamiliaridadB),
    send(Motivo,selection,MotivoB),
    send(CampoRes,selection,RespuestaB),
    send(CampoImg,selection,ImagenB),
    send(CampoExp,selection,ExplicacionB),

    %-----------Crear imagen
   new(Figure, figure),
   new(Bitmap, bitmap(resource(ImagenB),@on)),
   send(Bitmap, name, 1),
   send(Figure, display, Bitmap),
   send(Figure, status, 1),
   send(VentanaUsuario, display,Figure, point(400,200)),


    send(VentanaUsuario,display,Etiqueta,point(140,0)),
    send(VentanaUsuario,display,Genero,point(10,40)),
    send(VentanaUsuario,display,Edad,point(10,70)),
    send(VentanaUsuario,display,Familiaridad,point(10,100)),
    send(VentanaUsuario,display,Motivo,point(10,130)),
    send(VentanaUsuario,display,CampoRes,point(10,160)),
    send(VentanaUsuario,display,CampoImg,point(10,190)),
    send(VentanaUsuario,display,ResExperta,point(100,500)),
    send(VentanaUsuario,display,ResExplicacion,point(450,500)),
    send(VentanaUsuario,display,BTNsalir,point(750,500)),
    send(VentanaUsuario,open(point(100,100))),
    send(Ventana,destroy).

mostarExplicacion(Ventana,Campo):-
    send(Ventana,display,Campo,point(10,470)).

volverUsuario(Ventana):-
    send(Ventana,destroy),
    usuario.

    %BASE DE HECHOS........................................................
:-dynamic(genero/2).
genero('respuesta','genero').
%Hombre-menor-informal
genero('Hola, creo que es la primera vez que te por aqu�, me llamo _, �Cu�l es tu nombre?','Hombre').
genero('Que hay, ya hemos hablado antes �recuerdas? �C�mo has estado?','Hombre').
genero('Hola ____, deberiamos pedir algo para beber mientras hablamos','Hombre').
%Hombre-menor-formal
genero('Buen dia, pareces mas joven, �eres nuevo aqu�?,mucho gusto soy __','Hombre').
genero('Buenos dias ____ �Van bien los trabajos que te han entregado?, si tienes dudas puedes preguntarme','Hombre').
genero('Buen dia, espero que te este yendo tan bien como siempre','Hombre').
%Hombre-menor-pedirinfo
genero('Buenos dias, disculpa, de casualidad sabes acerca de_____, muchas gracias','Hombre').
genero('Buen dia, disculpa por volver a molestarte, tienes informacion de _____','Hombre').
genero('Buenos dias, creo que se ha vuelto un poco costumbre pero podia preguntarte acerca de ___','Hombre').
%Hombre-Menor-Ligar
genero('Antes de iniciar la conversaci�n acercate sonriendo y prensentate, menciona algo relacionado con el lugar en el que se encuentren','Hombre').
genero('Comentale que te da gusto verlo de nuevo y preguntale como le ha ido','Hombre').
genero('Inv�talo a salir a un lugar donde puedan platicar de otros temas','Hombre').

%Hombre-mismo rango-informal
genero('Que hay amigo, creo que nunca hemos hablado, me llamo ___, �C�mo te llamas?','Hombre').
genero('Hey amigo, que raro verte por aqu�, deberiamos salir a comer para ponernos al dia','Hombre').
genero('Hombre, �Qu� has esado haciendo? No hemos jugado estos dias jaja','Hombre').
%Hombre-mismo rango formal
genero('Buenos dias compa�ero, me llamo ____, �Cu�l es tu nombre?','Hombre').
genero('Que tal compa�ero, �C�mo va el trabajo hasta ahora?','Hombre').
genero('�C�mo va la situacion compa�ero? Veo que vamos bien','Hombre').
%Hombre-mismo rango-pedir info
genero('Hola, disculpa, sabes acerca de _____','Hombre').
genero('Oye amigo, diculpa, sera que me puedas dar informacion acerca de______','Hombre').
genero('�C�mo va todo? Disculpa ser que me pudieras dar informacion acerca de ______','Hombre').
%Hombre-Mismo rango-Ligar
genero('Pres�ntate con �l e intenta mantener un ambiente agradable entre los dos, puedes invitarle alg�n tipo de bebida para amenizar la pl�tica','Hombre').
genero('Recu�rdale las cosas por las que se conocieron e intenta llevar la pl�tica a un nivel m�s �ntimo, busca si tienen gustos en com�n, dile que te da gusto encontr�rtelo de nuevo','Hombre').
genero('Cuando te sientas en confianza con �l, intenta tener alg�n tipo de contacto f�sico y hazle saber tus intenciones','Hombre').

%Hombre-Mayor-Informal
genero('Buen dia se�or, �C�mo se encuentra? Me llamo _____','Hombre').
genero('Hola se�or, �C�mo a estado? No lo habia visto por aqu�','Hombre').
genero('�C�mo se encuentra? Don, parece que se esta divirtiendo','Hombre').
%Hombre-Mayor-Formal
genero('Buenos dias se�or, Me presento soy ______','Hombre').
genero('Buen dia se�or, espero que este teniendo un excelente dia','Hombre').
genero('Buen dia, parece que esta teiendo un buen dia, espero que siga asi','Hombre').
%Hombre-Mayor-pedir info
genero('Buen dia se�or, disculpe, podria ayudarme acerca de_____','Hombre').
genero('Buen dia, disculpe, tendria informacion de ____','Hombre').
genero('Hola, �como se encuentra?, sera que me pueda ayudar con esta informacion','Hombre').
%Hombre-Mayor-ligar
genero('Establece contacto visual con �l y sonr�ele, para despu�s poder acercarte a �l','Hombre').
genero('Preg�ntale sobre el tiempo en el que no estuvieron en contacto y hazle saber que extra�aste estar con �l','Hombre').
genero('S� directa con �l, aprovecha el v�nculo y dile las cosas que te gustan hacer con �l, as� como lo que sientes cuando est�n juntos','Hombre').
%Mujer-Menor
genero('','Mujer').
genero('','Mujer').
genero('','Mujer').
%Mujer-Mismo rango
genero('','Mujer').
genero('','Mujer').
genero('','Mujer').
%Mujer-Mayor
genero('','Mujer').
genero('','Mujer').
genero('','Mujer').
%No lo se-Menor
genero('','No lo se').
genero('','No lo se').
genero('','No lo se').
%No lo se-Mismo rango
genero('','No lo se').
genero('','No lo se').
genero('','No lo se').
%No lo se-Mayor
genero('','No lo se').
genero('','No lo se').
genero('','No lo se').

:-dynamic(edad/2).
edad('respuesta','edad').
%Hombre-menor-informal
edad('Hola, creo que es la primera vez que te por aqu�, me llamo _, �Cu�l es tu nombre?','Es menor').
edad('Que hay, ya hemos hablado antes �recuerdas? �C�mo has estado?','Es menor').
edad('Hola ____, deberiamos pedir algo para beber mientras hablamos','Es menor').
%Hombre-menor-formal
edad('Buen dia, pareces mas joven, �eres nuevo aqu�?,mucho gusto soy __','Es menor').
edad('Buenos dias ____ �Van bien los trabajos que te han entregado?, si tienes dudas puedes preguntarme','Es menor').
edad('Buen dia, espero que te este yendo tan bien como siempre','Es menor').
%Hombre-menor-pedirinfo
edad('Buenos dias, disculpa, de casualidad sabes acerca de_____, muchas gracias','Es menor').
edad('Buen dia, disculpa por volver a molestarte, tienes informacion de _____','Es menor').
edad('Buenos dias, creo que se ha vuelto un poco costumbre pero podia preguntarte acerca de ___','Es menor').
%Hombre-Menor-ligar
edad('Antes de iniciar la conversaci�n acercate sonriendo y prensentate, menciona algo relacionado con el lugar en el que se encuentren','Es menor').
edad('Comentale que te da gusto verlo de nuevo y preguntale como le ha ido','Es menor').
edad('Inv�talo a salir a un lugar donde puedan platicar de otros temas','Es menor').

%Hombre-mismo rango-informal
edad('Que hay amigo, creo que nunca hemos hablado, me llamo ___, �C�mo te llamas?','Mismo rango de edad').
edad('Hey amigo, que raro verte por aqu�, deberiamos salir a comer para ponernos al dia','Mismo rango de edad').
edad('Hombre, �Qu� has esado haciendo? No hemos jugado estos dias jaja','Mismo rango de edad').
%Hombre-mismo rango formal
edad('Buenos dias compa�ero, me llamo ____, �Cu�l es tu nombre?','Mismo rango de edad').
edad('Que tal compa�ero, �C�mo va el trabajo hasta ahora?','Mismo rango de edad').
edad('�C�mo va la situacion compa�ero? Veo que vamos bien','Mismo rango de edad').
%Hombre-mismo rango-pedir info
edad('Hola, disculpa, sabes acerca de _____','Mismo rango de edad').
edad('Oye amigo, diculpa, sera que me puedas dar informacion acerca de______','Mismo rango de edad').
edad('�C�mo va todo? Disculpa ser que me pudieras dar informacion acerca de ______','Mismo rango de edad').
%Hombre-Mismo rango
edad('Pres�ntate con �l e intenta mantener un ambiente agradable entre los dos, puedes invitarle alg�n tipo de bebida para amenizar la pl�tica','Mismo rango de edad').
edad('Recu�rdale las cosas por las que se conocieron e intenta llevar la pl�tica a un nivel m�s �ntimo, busca si tienen gustos en com�n, dile que te da gusto encontr�rtelo de nuevo','Mismo rango de edad').
edad('Cuando te sientas en confianza con �l, intenta tener alg�n tipo de contacto f�sico y hazle saber tus intenciones','Mismo rango de edad').

%Hombre-Mayor-Informal
edad('Buen dia se�or, �C�mo se encuentra? Me llamo _____','Es mayor').
edad('Hola se�or, �C�mo a estado? No lo habia visto por aqu�','Es mayor').
edad('�C�mo se encuentra? Don, parece que se esta divirtiendo','Es mayor').
%Hombre-Mayor-Formal
edad('Buenos dias se�or, Me presento soy ______','Es mayor').
edad('Buen dia se�or, espero que este teniendo un excelente dia','Es mayor').
edad('Buen dia, parece que esta teiendo un buen dia, espero que siga asi','Es mayor').
%Hombre-Mayor-pedir info
edad('Buen dia se�or, disculpe, podria ayudarme acerca de_____','Es mayor').
edad('Buen dia, disculpe, tendria informacion de ____','Es mayor').
edad('Hola, �como se encuentra?, sera que me pueda ayudar con esta informacion','Es mayor').
%Hombre-Mayor-ligar
edad('Establece contacto visual con �l y sonr�ele, para despu�s poder acercarte a �l','Es mayor').
edad('Preg�ntale sobre el tiempo en el que no estuvieron en contacto y hazle saber que extra�aste estar con �l','Es mayor').
edad('S� directa con �l, aprovecha el v�nculo y dile las cosas que te gustan hacer con �l, as� como lo que sientes cuando est�n juntos','Es mayor').

%Mujer-Menor
edad('','Es menor').
edad('','Es menor').
edad('','Es menor').
%Mujer-Mismo rango
edad('','Mismo rango de edad').
edad('','Mismo rango de edad').
edad('','Mismo rango de edad').
%Mujer-Mayor
edad('','Es mayor').
edad('','Es mayor').
edad('','Es mayor').
%No lo se-Menor
edad('','Es menor').
edad('','Es menor').
edad('','Es menor').
%No lo se-Mismo rango
edad('','Mismo rango de edad').
edad('','Mismo rango de edad').
edad('','Mismo rango de edad').
%No lo se-Mayor
edad('','Es mayor').
edad('','Es mayor').
edad('','Es mayor').


:-dynamic(familiaridad/2).
familiaridad('respuesta','Familiaridad').

%Hombre-menor-nunca
familiaridad('Hola, creo que es la primera vez que te por aqu�, me llamo _, �Cu�l es tu nombre?','Nunca hemos hablado').
familiaridad('Buen dia, pareces mas joven, �eres nuevo aqu�?,mucho gusto soy __','Nunca hemos hablado').
familiaridad('Buenos dias, disculpa, de casualidad sabes acerca de_____, muchas gracias','Nunca hemos hablado').

%Hombre-menor-aveces
familiaridad('Que hay, ya hemos hablado antes �recuerdas? �C�mo has estado?','Hemos cruzado palabras').
familiaridad('Buenos dias ____ �Van bien los trabajos que te han entregado?, si tienes dudas puedes preguntarme','Hemos cruzado palabras').
familiaridad('Buen dia, disculpa por volver a molestarte, tienes informacion de _____','Hemos cruzado palabras').

%Hombre-menor-frecuentemente
familiaridad('Hola ____, deberiamos pedir algo para beber mientras hablamos','Hablamos frecuentemente').
familiaridad('Buen dia, espero que te este yendo tan bien como siempre','Hablamos frecuentemente').
familiaridad('Buenos dias, creo que se ha vuelto un poco costumbre pero podia preguntarte acerca de ___','Hablamos frecuentemente').

%Hombre-mismaedad-nunca
familiaridad('Que hay amigo, creo que nunca hemos hablado, me llamo ___, �C�mo te llamas?','Nunca hemos hablado').
familiaridad('Buenos dias compa�ero, me llamo ____, �Cu�l es tu nombre?','Nunca hemos hablado').
familiaridad('Hola, disculpa, sabes acerca de _____','Nunca hemos hablado').

%Hombre-mismaedad-aveces
familiaridad('Hey amigo, que raro verte por aqu�, deberiamos salir a comer para ponernos al dia','Hemos cruzado palabras').
familiaridad('Que tal compa�ero, �C�mo va el trabajo hasta ahora?','Hemos cruzado palabras').
familiaridad('Oye amigo, diculpa, sera que me puedas dar informacion acerca de______','Hemos cruzado palabras').

%Hombre-mismaedad-frecuentemente
familiaridad('Hombre, �Qu� has esado haciendo? No hemos jugado estos dias jaja','Hablamos frecuentemente').
familiaridad('�C�mo va la situacion compa�ero? Veo que vamos bien ','Hablamos frecuentemente').
familiaridad('�C�mo va todo? Disculpa ser que me pudieras dar informacion acerca de ______','Hablamos frecuentemente').

%Hombre-mayor-nunca
familiaridad('Buen dia se�or, �C�mo se encuentra? Me llamo _____','Nunca hemos hablado').
familiaridad('Buenos dias se�or, Me presento soy ______','Nunca hemos hablado').
familiaridad('Buen dia se�or, disculpe, podria ayudarme acerca de_____','Nunca hemos hablado').

%Hombre-mayor-aveces
familiaridad('Hola se�or, �C�mo a estado? No lo habia visto por aqu�','Hemos cruzado palabras').
familiaridad('Buen dia se�or, espero que este teniendo un excelente dia','Hemos cruzado palabras').
familiaridad('Buen dia, disculpe, tendria informacion de ____','Hemos cruzado palabras').

%Hombre-mayor-frecuentemente
familiaridad('�C�mo se encuentra? Don, parece que se esta divirtiendo','Hablamos frecuentemente').
familiaridad('Buen dia, parece que esta teiendo un buen dia, espero que siga asi','Hablamos frecuentemente').
familiaridad('Hola, �como se encuentra?, sera que me pueda ayudar con esta informacion','Hablamos frecuentemente').

%Hombre-Nunca-ligar
familiaridad('Antes de iniciar la conversaci�n acercate sonriendo y prensentate, menciona algo relacionado con el lugar en el que se encuentren','Nunca hemos hablado').
familiaridad('Pres�ntate con �l e intenta mantener un ambiente agradable entre los dos, puedes invitarle alg�n tipo de bebida para amenizar la pl�tica','Nunca hemos hablado').
familiaridad('Establece contacto visual con �l y sonr�ele, para despu�s poder acercarte a �l','Nunca hemos hablado').


%Hombre-Hemos cruzado palabras
familiaridad('Comentale que te da gusto verlo de nuevo y preguntale como le ha ido','Hemos cruzado palabras').
familiaridad('Recu�rdale las cosas por las que se conocieron e intenta llevar la pl�tica a un nivel m�s �ntimo, busca si tienen gustos en com�n, dile que te da gusto encontr�rtelo de nuevo','Hemos cruzado palabras').
familiaridad('Preg�ntale sobre el tiempo en el que no estuvieron en contacto y hazle saber que extra�aste estar con �l','Hemos cruzado palabras').


%Hombre-Hablamos frecuentemente
familiaridad('Inv�talo a salir a un lugar donde puedan platicar de otros temas','Hablamos frecuentemente').
familiaridad('Cuando te sientas en confianza con �l, intenta tener alg�n tipo de contacto f�sico y hazle saber tus intenciones','Hablamos frecuentemente').
familiaridad('S� directa con �l, aprovecha el v�nculo y dile las cosas que te gustan hacer con �l, as� como lo que sientes cuando est�n juntos','Hablamos frecuentemente').

%Mujer-Nunca
familiaridad('','Nunca hemos hablado').
familiaridad('','Nunca hemos hablado').
familiaridad('','Nunca hemos hablado').
%Mujer-Hemos cruzado palabras
familiaridad('','Hemos cruzado palabras').
familiaridad('','Hemos cruzado palabras').
familiaridad('','Hemos cruzado palabras').
%Mujer-Hablamos frecuentemente
familiaridad('','Hablamos frecuentemente').
familiaridad('','Hablamos frecuentemente').
familiaridad('','Hablamos frecuentemente').

%No lo se-Nunca
familiaridad('','Nunca hemos hablado').
familiaridad('','Nunca hemos hablado').
familiaridad('','Nunca hemos hablado').
%No lo se-cruzado palabras
familiaridad('','Hemos cruzado palabras').
familiaridad('','Hemos cruzado palabras').
familiaridad('','Hemos cruzado palabras').
%No lo se-frecuentemente
familiaridad('','Hablamos frecuentemente').
familiaridad('','Hablamos frecuentemente').
familiaridad('','Hablamos frecuentemente').


:-dynamic(motivo/2).
motivo('respuesta','Motivo').

%Hombre-menor-informal
motivo('Hola, creo que es la primera vez que te por aqu�, me llamo _, �Cu�l es tu nombre?','Platica informal').
motivo('Que hay, ya hemos hablado antes �recuerdas? �C�mo has estado?','Platica informal').
motivo('Hola ____, deberiamos pedir algo para beber mientras hablamos','Platica informal').
%Hombre-menor-formal
motivo('Buen dia, pareces mas joven, �eres nuevo aqu�?,mucho gusto soy __','Platica formal').
motivo('Buenos dias ____ �Van bien los trabajos que te han entregado?, si tienes dudas puedes preguntarme','Platica formal').
motivo('Buen dia, espero que te este yendo tan bien como siempre','Platica formal').
%Hombre-menor-pedirinfo
motivo('Buenos dias, disculpa, de casualidad sabes acerca de_____, muchas gracias','Pedir informacion').
motivo('Buen dia, disculpa por volver a molestarte, tienes informacion de _____','Pedir informacion').
motivo('Buenos dias, creo que se ha vuelto un poco costumbre pero podia preguntarte acerca de ___','Pedir infrmacion').
%Hombre-Menor
motivo('Antes de iniciar la conversaci�n acercate sonriendo y prensentate, menciona algo relacionado con el lugar en el que se encuentren','Ligar').
motivo('Comentale que te da gusto verlo de nuevo y preguntale como le ha ido','Ligar').
motivo('Inv�talo a salir a un lugar donde puedan platicar de otros temas','Ligar').


%Hombre-Mismo rango
motivo('Pres�ntate con �l e intenta mantener un ambiente agradable entre los dos, puedes invitarle alg�n tipo de bebida para amenizar la pl�tica','Ligar').
motivo('Recu�rdale las cosas por las que se conocieron e intenta llevar la pl�tica a un nivel m�s �ntimo, busca si tienen gustos en com�n, dile que te da gusto encontr�rtelo de nuevo','Ligar').
motivo('Cuando te sientas en confianza con �l, intenta tener alg�n tipo de contacto f�sico y hazle saber tus intenciones','Ligar').
%Hombre-Mayor
motivo('Establece contacto visual con �l y sonr�ele, para despu�s poder acercarte a �l','Ligar').
motivo('Preg�ntale sobre el tiempo en el que no estuvieron en contacto y hazle saber que extra�aste estar con �l','Ligar').
motivo('S� directa con �l, aprovecha el v�nculo y dile las cosas que te gustan hacer con �l, as� como lo que sientes cuando est�n juntos','Ligar').

%Mujer-Menor
motivo('','Ligar').
motivo('','Ligar').
motivo('','Ligar').
%Mujer-Mismo rango
motivo('','Ligar').
motivo('','Ligar').
motivo('','Ligar').
%Mujer-Mayor
motivo('','Ligar').
motivo('','Ligar').
motivo('','Ligar').

%No lo se-Mayor
motivo('','Ligar').
motivo('','Ligar').
motivo('','Ligar').
%No lo se-Mismo rango
motivo('','Ligar').
motivo('','Ligar').
motivo('','Ligar').
%No lo se-Mayor
motivo('','Ligar').
motivo('','Ligar').
motivo('','Ligar').

:-dynamic(explicacion/2).
explicacion('respuesta','explicacion').

%Hombre-Menor
explicacion('Antes de iniciar la conversaci�n acercate sonriendo y prensentate, menciona algo relacionado con el lugar en el que se encuentren','Se busca llamar la atenci�n de el con la sonrisa, creando una reacci�n positiva').
explicacion('Comentale que te da gusto verlo de nuevo y preguntale como le ha ido','Le agradar� saber que est�s feliz de verlo y probablemente el igual lo est� despues del comentario').
explicacion('Inv�talo a salir a un lugar donde puedan platicar de otros temas','La idea es que te permitas hablar con mayor intimidad sobre ustedes dos y si quisieran avanzar en el tipo de relaci�n que ya tienen').
%Hombre-Mismo rango
explicacion('Pres�ntate con �l e intenta mantener un ambiente agradable entre los dos, puedes invitarle alg�n tipo de bebida para amenizar la pl�tica','Deja que �l te conozca y con�celo tambi�n para identificar las cosas que les gustan m�s del otro').
explicacion('Recu�rdale las cosas por las que se conocieron e intenta llevar la pl�tica a un nivel m�s �ntimo, busca si tienen gustos en com�n, dile que te da gusto encontr�rtelo de nuevo','Fortalece ese lazo que los uni� en el inicio conociendo m�s sobre �l').
explicacion('Cuando te sientas en confianza con �l, intenta tener alg�n tipo de contacto f�sico y hazle saber tus intenciones','La idea es que sean claros con lo que sienten el uno por el otro, por eso debes hacerle saber qu� quieres').
%Hombre-Mayor
explicacion('Establece contacto visual con �l y sonr�ele, para despu�s poder acercarte a �l','Recuerda que la primera impresi�n es lo que cuenta, entonces si te acercas con confianza podr�as entablar una pl�tica madura').
explicacion('Preg�ntale sobre el tiempo en el que no estuvieron en contacto y hazle saber que extra�aste estar con �l','Recordar buenos momentos siempre es una buena estrategia para agarrar confianza r�pido').
explicacion('S� directa con �l, aprovecha el v�nculo y dile las cosas que te gustan hacer con �l, as� como lo que sientes cuando est�n juntos','Hazle notar que te importa y que buscas algo m�s de la relaci�n').

%Mujer-Menor
explicacion('','').
explicacion('','').
explicacion('','').
%Mujer-Mismo rango
explicacion('','').
explicacion('','').
explicacion('','').
%Mujer-Mayor
explicacion('','').
explicacion('','').
explicacion('','').

%No lo se-Mayor
explicacion('','').
explicacion('','').
explicacion('','').
%No lo se-Mismo rango
explicacion('','').
explicacion('','').
explicacion('','').
%No lo se-Mayor
explicacion('','').
explicacion('','').
explicacion('','').

:-dynamic(imagen/2).
imagen('respuesta','img').
%Hombre-Menor
imagen('Antes de iniciar la conversaci�n acercate sonriendo y prensentate, menciona algo relacionado con el lugar en el que se encuentren','1-1-1-2.jpg').
imagen('Comentale que te da gusto verlo de nuevo y preguntale como le ha ido','1-1-2-2.jpg').
imagen('Inv�talo a salir a un lugar donde puedan platicar de otros temas','1-1-3-2.jpg').
%Hombre-Mismo rango
imagen('Pres�ntate con �l e intenta mantener un ambiente agradable entre los dos, puedes invitarle alg�n tipo de bebida para amenizar la pl�tica','1-2-1-2.jpg').
imagen('Recu�rdale las cosas por las que se conocieron e intenta llevar la pl�tica a un nivel m�s �ntimo, busca si tienen gustos en com�n, dile que te da gusto encontr�rtelo de nuevo','1-2-2-2.jpg').
imagen('Cuando te sientas en confianza con �l, intenta tener alg�n tipo de contacto f�sico y hazle saber tus intenciones','1-2-3-2.jpg').
%Hombre-Mayor
imagen('Establece contacto visual con �l y sonr�ele, para despu�s poder acercarte a �l','1-3-1-2.jpg').
imagen('Preg�ntale sobre el tiempo en el que no estuvieron en contacto y hazle saber que extra�aste estar con �l','1-3-2-2.jpg').
imagen('S� directa con �l, aprovecha el v�nculo y dile las cosas que te gustan hacer con �l, as� como lo que sientes cuando est�n juntos','1-3-3-2.jpg').

:-dynamic(resource/3).
resource('nombre',image,image('nombre')).
%Hombre
resource('1-1-1-2.jpg',image,image('1-1-1-2.jpg')).
resource('1-1-2-2.jpg',image,image('1-1-2-2.jpg')).
resource('1-1-3-2.jpg',image,image('1-1-3-2.jpg')).
resource('1-2-1-2.jpg',image,image('1-2-1-2.jpg')).
resource('1-2-2-2.jpg',image,image('1-2-2-2.jpg')).
resource('1-2-3-2.jpg',image,image('1-2-3-2.jpg')).
resource('1-3-1-2.jpg',image,image('1-2-3-2.jpg')).
resource('1-3-2-2.jpg',image,image('1-3-2-2.jpg')).
resource('1-3-3-2.jpg',image,image('1-3-3-2.jpg')).

%Mujer



%BASE DE CONOCIMIENTO...................................................
respuesta_experta(Genero, Edad, Familiaridad, Motivo, Respuesta,Explicacion,Imagen):-
    genero(Respuesta,Genero),
    edad(Respuesta,Edad),
    familiaridad(Respuesta,Familiaridad),
    motivo(Respuesta,Motivo),
    explicacion(Respuesta,Explicacion),
    imagen(Respuesta,Imagen).




